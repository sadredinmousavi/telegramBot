<?php

error_reporting(E_ERROR);
   
    $action = $_post['action'];
    $password = $_POST['password'];
    $valid_password = 'ali125';
    //
    //
    //
    if ($password == $valid_password){
        switch ($action) {
            case 'set_hook':
                $url = 'https://kafegame.com/bot/set.php';
                break;

            case 'unset_hook':
                $url = 'https://kafegame.com/bot/unset.php';
                break;

            case 'get_update':
                $url = 'https://kafegame.com/bot/getUpdatesCLI.php';
                break;
            
            default:
                break;
        }
        $data = array('user' => 'ali125', 'pass' => 'ali125');

        // // use key 'http' even if you send the request to https://...
        // $options = array(
        //     'http' => array(
        //         'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
        //         'method'  => 'POST',
        //         'content' => http_build_query($data)
        //     )
        // );
        // $context  = stream_context_create($options);
        // $result = file_get_contents($url, false, $context);
        // if ($result === FALSE) {
        //     /* Handle error */ 
        // }

        // //var_dump($result);
        ?>
        <script type='text/javascript'>
        document.redirect.submit();
        </script>
        <?php

    } else {
        echo "you don't have permission";
    }
    exit;
?>
<html>
<form name='redirect' action='<?php echo $url; ?>' method='POST'>
<input type='hidden' name='username' value='<?php echo $data['user']; ?>'>
<input type='hidden' name='password' value='<?php echo $data['pass']; ?>'>
<input type='submit' value='Proceed'>
</form>
<script type='text/javascript'>
document.redirect.submit();
</script>
</html>

