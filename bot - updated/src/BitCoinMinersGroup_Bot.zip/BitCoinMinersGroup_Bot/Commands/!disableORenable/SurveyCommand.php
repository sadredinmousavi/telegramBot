<?php

namespace Longman\TelegramBot\Commands\UserCommands;

use Longman\TelegramBot\Commands\UserCommand;

class SurveyCommand extends UserCommand
{
    protected $enabled = false;

    public function execute()
    {
    }
}
