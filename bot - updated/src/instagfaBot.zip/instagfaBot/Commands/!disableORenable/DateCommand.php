<?php

namespace Longman\TelegramBot\Commands\UserCommands;

use Longman\TelegramBot\Commands\UserCommand;

class DateCommand extends UserCommand
{
    protected $enabled = false;

    public function execute()
    {
    }
}
