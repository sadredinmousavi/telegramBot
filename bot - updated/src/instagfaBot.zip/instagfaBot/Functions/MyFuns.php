<?php

namespace Longman\TelegramBot;

use \Mylib\DB AS InstaDB;
use core;


class MyFuns
{
    protected $upload_path;

    protected $download_path;

    static protected $mysql_credentials = [];


    //
    //


    public function __construct()
    {

    }



    public function selectionOptionsCreator($channel_id){
        $channels = InstaDB::selectChannels();
        $channel = $channels[array_search($channel_id, array_column($channels, 'channel_id'))];
        $options =[];
        $options['not_published_in'] = $channel['channel_id'];
        $options['user_belongs_to_channel'] = $channel['channel_id'];
        $options['scanned'] = 1;
        //'user_not_publisih_x_recent_post' => 5
        return $options;
    }






    public function publish_update_posts($channel_id, $type = null, $publish_or_update = 'update'){
        $selection = ['videos' => false, 'images' => false, 'carousels' => false];
        $selection[$type] = true;
        //
        $channels = InstaDB::selectChannels();
        $channel = $channels[array_search($channel_id, array_column($channels, 'channel_id'))];
        //
        $options = self::selectionOptionsCreator($channel_id);
        $options['limit_rows'] = $channel[$type];
        //
        if ($publish_or_update === 'publish'){
            $a = InstaDB::selectMedia($selection, $options, $date_from = strtotime("-" .$channel['date_from'] ." day"));
        } elseif($publish_or_update === 'update'){
            $a = InstaDB::selectPublished($channel['channel_id']);
        }

        // echo "<pre>";
        // print_r($a);
        // echo "</pre>";
        if(empty($a)){
            return true;
            //continue;
        }

        foreach ($a as $media) {
            switch ($media['type']) {
                case 'image':
                    $type = 'photo';
                    break;
                case 'video':
                    $type = 'video';
                    break;
                case 'carousel':
                    $type = 'photo';
                    break;
                default:
                    $type = 'photo';
                    break;
            }

            if (checkCaptionForAds($media)){
                continue;
            }
            //
            //Rules
            if ($channel_id === '-1001332864326'){
                $media['caption']='';
            }
            //

            $media['caption'] = caption_preProcess($media);

            if (empty($media['full_name']))
                $media['full_name'] = $media['username'];

            if(!isset($media['link']))
                $media['link'] = 'https://www.instagram.com/p/' .$media['code'];

            //
            //
            //
            //
            //

            if ($publish_or_update === 'update')
                unset($channel);
            publish_update_method_1($media, $channel){
        }

    }







    public function checkCaptionForAds($media){
        $words = InstaDB::selectBlackWords();
        $penalty = 0;
        foreach ($words as $word) {
            if (mb_stripos($media['caption'], $word['word'], $encoding = 'utf8mb4_unicode_520_ci')>0){
                $penalty += $word['penalty'];
            }
        }
        if ($penalty >= 10){
            InstaDB::insertPublished($channel_id, $media['media_id'], null, $type, null);
            return true;
        } else {
            return false;
        }
    }







    public function caption_preProcess($media){
        preg_match_all("/#\S+\s*/i", $media['caption'], $hastags);//extract all hastags
        preg_match_all("/@\S+\s*/i", $media['caption'], $mentions);//extract all mentions
        //$media['caption'] = preg_replace("/#([\p{L}\d_]+)/u", " \' .json_decode(\'\"\u270D\uFE0F\"\') .\'$1,", $media['caption']);//preg_replace("/#([\p{L}\d_]+)/u", "($1)", $media['caption']);//put hashtag into prantheses
        $hashtag = json_decode('"\u0023\u20E3"');
        $media['caption'] = str_replace('#', $hashtag, $media['caption']);
        //
        $media['caption'] = str_replace('<', "\"", $media['caption']);
        $media['caption'] = str_replace('>', "\"", $media['caption']);
        if (empty($media['full_name']))
            $media['full_name'] = $media['username'];
        //$media['caption'] = preg_replace("/@([\p{L}\d_]+)/u", " $1 ", $media['caption']);//preg_replace("/@([\p{L}\d_]+)/u", "([at]$1)", $media['caption']);//put atsign into prantheses
        preg_replace("/([\p{L}\d_]+?)(\n+)([\p{L}\d_]+?)/", "$1\n$3", $media['caption']);//remove duplicate \n s

        return $media['caption'];
    }







    public function publish_update_method_1($media, $channel = null){
        if (null !== $channel){
            $publish_or_update = 'update';
            $channel_id = $media['channel_id'];
            $ch_username = $media['user_name'];//$posts['channel_username'];
        } else {
            $publish_or_update = 'publish';
            $channel_id = $channel['channel_id'];
            $ch_username = $channel['user_name'];//$posts['channel_username'];
        }


        switch ($media['type']) {
            case 'image':
                $type = 'photo';
                break;
            case 'video':
                $type = 'video';
                break;
            case 'carousel':
                $type = 'photo';
                break;
            default:
                $type = 'photo';
                break;
        }

        $standard_caption_length = true;
        $limit = 120;
        if (strlen($media['caption'])>$limit){
            $string = substr($media['caption'], 0 ,strpos($media['caption'], ' ', $limit-10));
            $string = wordwrap($media['caption'], $limit);
            $caption = substr($string, 0, strpos($string, "\n", $limit-10)) .'    ' .'(ادامه کپشن در پست بعدی)';
            $standard_caption_length = false;
        } else {
            $caption = $media['caption'];
        }

        //
        //
        //
        if($standard_caption_length){
            $atsign = json_decode('"\uD83C\uDD94"');
            $caption = str_replace('@', $atsign, $caption);
            //
            $data = [];
            $data['chat_id'] = $channel_id;
            $data['caption'] = //json_decode('"\uD83D\uDC64"') .$media['username'] .json_decode('"\uD83D\uDC64"')
                              //.PHP_EOL .json_decode('"\u2764\uFE0F"') .' ' .$media['likes']
                              json_decode('"\u270D\uFE0F"') .' #' .preg_replace("/([^\p{L}\d_ ]+)/u", "", str_replace(" ", "_", $media['full_name']))
                              .PHP_EOL .$caption
                              .PHP_EOL .PHP_EOL .json_decode('"\uD83D\uDC49"') .' @' .$ch_username;
            $data['disable_notification'] = true;
            //
            if ($type === 'photo') {
                $data['photo'] = $media['img_standard_resolution'];
            } elseif ($type === 'video') {
                $data['video'] = $media['vid_standard_resolution'];
            }

            if ($publish_or_update === 'publish'){
                $callback_path     = 'Longman\TelegramBot\Request';
                $callback_function = 'send' . ucfirst($type);
                if (!method_exists($callback_path, $callback_function)) {
                    throw new TelegramException('Methods: ' . $callback_function . ' not found in class Request.');
                }
                //
                $result = $callback_path::$callback_function($data);
            } else if ($publish_or_update === 'update') {
                $data['message_id'] = $media['post_id'];
                if ($type === 'message') {
                    $type2 = 'text';
                //} elseif ($type === 'photo') {
                } elseif ($type === 'image') {
                    $type2 = 'caption';
                } elseif ($type === 'video') {
                    $type2 = 'caption';
                }
                $callback_path     = 'Longman\TelegramBot\Request';
                $callback_function = 'editMessage' . ucfirst($type2);
                if (!method_exists($callback_path, $callback_function)) {
                    throw new TelegramException('Methods: ' . $callback_function . ' not found in class Request.');
                }
                //
                $result = $callback_path::$callback_function($data);
            }

        } else {
            if ($publish_or_update === 'publish'){
                $data = [];
                $data['chat_id'] = '-1001197492471';
                $data['caption'] = json_decode('"\u2764\uFE0F"') .' ' .$media['full_name'] .json_decode('"\u2764\uFE0F"');
                                  //.PHP_EOL .'به ما بپیوندید'
                                  //.PHP_EOL .json_decode('"\uD83D\uDC49"') .' @' .$ch_username;
                $data['disable_notification'] = true;
                //
                if ($type === 'photo') {
                    $data['photo'] = $media['img_standard_resolution'];
                } elseif ($type === 'video') {
                    $data['video'] = $media['vid_standard_resolution'];
                }

                $callback_path     = 'Longman\TelegramBot\Request';
                $callback_function = 'send' . ucfirst($type);
                // echo "<pre>";
                // print_r($data);
                // echo $callback_path .'  ' .$callback_function .'  ';
                // echo "</pre>";
                if (!method_exists($callback_path, $callback_function)) {
                    throw new TelegramException('Methods: ' . $callback_function . ' not found in class Request.');
                }
                //
                $result = $callback_path::$callback_function($data);
                if ($result->isOK()){
                } else {
                    // echo "<pre>";
                    // print_r($result);
                    // echo "</pre>";
                    throw new TelegramException('post was not published! Error: ' . $result->getErrorCode() . ' ' . $result->getDescription());
                    InstaDB::updateMedia($media['media_id'], ['scanned' => 0]);
                }
                $a = $result;
                //echo "<pre>";
                //print_r($result);
                //echo "</pre>";
                //InstaDB::insertPublished($channel_id, $media['media_id'], $result->getResult()->getmessage_id());
            }


            if ($result->isOK() || $publish_or_update === 'update'){
                if ($publish_or_update === 'publish'){
                    $insfa_id = $result->getResult()->getmessage_id();
                } else if ($publish_or_update === 'update') {
                    $insfa_id = $media['insfa_id'];
                    if ($media['insfa_id'] == 0){
                        return true;
                    }
                }

                $media['caption'] = preg_replace("/@([\p{L}\d_.]+)/u", '<a href="https://instagram.com/$1">$1</a>' , $media['caption']);//preg_replace("/@([\p{L}\d_]+)/u", "([at]$1)", $media['caption']);//put atsign into prantheses
                $user_mention = '<a href="' .$media['link'] .'">' .$media['username'] .'</a>';
                //$user_mention_to_tele = '<a href="https://t.me/' . .'/' .$result->getResult()->getmessage_id() .'">' .$media['username'] .'</a>';
                $user_mention_to_tele = '<a href="https://t.me/insfa/' .$insfa_id .'">&#8205;</a>';
                $data2 = [];
                $data2['chat_id'] = $channel_id;
                $data2['text'] = //json_decode('"\uD83D\uDC64"') .$user_mention_to_tele .$user_mention .$user_mention_to_tele .json_decode('"\uD83D\uDC64"')
                              //.PHP_EOL .json_decode('"\u2764\uFE0F"') .' ' .$media['likes']
                              json_decode('"\u270D\uFE0F"') .' #' .preg_replace("/([^\p{L}\d_ ]+)/u", "", str_replace(" ", "_", $media['full_name'])) .$user_mention_to_tele
                              .PHP_EOL .PHP_EOL .$media['caption']
                              .PHP_EOL .PHP_EOL .json_decode('"\uD83D\uDC49"') .' @' .$ch_username;

                $data2['disable_web_page_preview'] = false;
                $data2['disable_notification'] = true;
                $data2['parse_mode'] = 'HTML';

                if ($publish_or_update === 'publish'){
                    $result = Request::sendMessage($data2);
                } else if ($publish_or_update === 'update') {
                    $data2['message_id'] = $media['post_id'];
                    $result = Request::editMessageText($data2);
                }

                if ($result->isOK()){
                    InstaDB::insertPublished($channel_id, $media['media_id'], $result->getResult()->getmessage_id(), 'message', $a->getResult()->getmessage_id());
                } elseif ($publish_or_update === 'publish') {
                    throw new TelegramException('post was not published! Error: ' . $result->getErrorCode() . ' ' . $result->getDescription());
                    InstaDB::updateMedia($media['media_id'], ['scanned' => 0]);
                }

            }
        }
    }



    public function publish_update_method_2($media, $channel = null){
        if (null !== $channel){
            $publish_or_update = 'update';
            $channel_id = $media['channel_id'];
            $ch_username = $media['user_name'];//$posts['channel_username'];
        } else {
            $publish_or_update = 'publish';
            $channel_id = $channel['channel_id'];
            $ch_username = $channel['user_name'];//$posts['channel_username'];
        }


        switch ($media['type']) {
            case 'image':
                $type = 'photo';
                break;
            case 'video':
                $type = 'video';
                break;
            case 'carousel':
                $type = 'photo';
                break;
            default:
                $type = 'photo';
                break;
        }

        $standard_caption_length = true;
        $limit = 120;
        if (strlen($media['caption'])>$limit){
            $string = substr($media['caption'], 0 ,strpos($media['caption'], ' ', $limit-10));
            $string = wordwrap($media['caption'], $limit);
            $caption = substr($string, 0, strpos($string, "\n", $limit-10)) .'    ' .'(ادامه کپشن در پست بعدی)';
            $standard_caption_length = false;
        } else {
            $caption = $media['caption'];
        }

        //
        //
        //
        if($standard_caption_length){
            $atsign = json_decode('"\uD83C\uDD94"');
            $caption = str_replace('@', $atsign, $caption);
            //
            $data = [];
            $data['chat_id'] = $channel_id;
            $data['caption'] = //json_decode('"\uD83D\uDC64"') .$media['username'] .json_decode('"\uD83D\uDC64"')
                              //.PHP_EOL .json_decode('"\u2764\uFE0F"') .' ' .$media['likes']
                              json_decode('"\u270D\uFE0F"') .' #' .preg_replace("/([^\p{L}\d_ ]+)/u", "", str_replace(" ", "_", $media['full_name']))
                              .PHP_EOL .$caption
                              .PHP_EOL .PHP_EOL .json_decode('"\uD83D\uDC49"') .' @' .$ch_username;
            $data['disable_notification'] = true;
            //
            if ($type === 'message') {
                //$data['text'] = $message->getText(true);
                //$data['text'] = 'asdasd';
            } elseif ($type === 'photo') {
                //$data['photo'] = $message->getPhoto()[0]->getFileId();
                $data['photo'] = $media['img_standard_resolution'];
            } elseif ($type === 'video') {
                $data['video'] = $media['vid_standard_resolution'];
            }

            if ($publish_or_update === 'publish'){
                $callback_path     = 'Longman\TelegramBot\Request';
                $callback_function = 'send' . ucfirst($type);
                if (!method_exists($callback_path, $callback_function)) {
                    throw new TelegramException('Methods: ' . $callback_function . ' not found in class Request.');
                }
                //
                $result = $callback_path::$callback_function($data);
            } else if ($publish_or_update === 'update') {
                $data['message_id'] = $media['post_id'];
                if ($type === 'message') {
                    $type2 = 'text';
                //} elseif ($type === 'photo') {
                } elseif ($type === 'image') {
                    $type2 = 'caption';
                } elseif ($type === 'video') {
                    $type2 = 'caption';
                }
                $callback_path     = 'Longman\TelegramBot\Request';
                $callback_function = 'editMessage' . ucfirst($type2);
                if (!method_exists($callback_path, $callback_function)) {
                    throw new TelegramException('Methods: ' . $callback_function . ' not found in class Request.');
                }
                //
                $result = $callback_path::$callback_function($data);
            }


            //echo "<pre>";
            //print_r($data);
            //print_r($result);
            //echo "</pre>";
            if ($result->isOK()){
                InstaDB::insertPublished($channel_id, $media['media_id'], $result->getResult()->getmessage_id(), $type, null);
            } else if ($publish_or_update === 'publish'){
                throw new TelegramException('post was not published! Error: ' . $result->getErrorCode() . ' ' . $result->getDescription());
                InstaDB::updateMedia($media['media_id'], ['scanned' => 0]);
            }

            if (!$standard_caption_length){
                $user_mention = '<a href="' .$media['link'] .'">' .$media['username'] .'</a>';
                //$user_mention_to_tele = '<a href="https://t.me/' . .'/' .$result->getResult()->getmessage_id() .'">' .$media['username'] .'</a>';
                $user_mention_to_tele = '<a href="https://t.me/' .$ch_username .'/' .$result->getResult()->getmessage_id() .'">&#8205;</a>';
                $data2 = [];
                $data2['chat_id'] = $channel_id;
                $data2['text'] = json_decode('"\uD83D\uDC64"') .$user_mention_to_tele .$user_mention .$user_mention_to_tele .json_decode('"\uD83D\uDC64"')
                              .PHP_EOL .json_decode('"\u2764\uFE0F"') .' ' .$media['likes']
                              .PHP_EOL .PHP_EOL .$media['caption']
                              .PHP_EOL .PHP_EOL .json_decode('"\uD83D\uDC49"') .' @' .$ch_username;

                $data2['disable_web_page_preview'] = false;
                $data2['disable_notification'] = true;
                $data2['parse_mode'] = 'HTML';

                if ($publish_or_update === 'publish'){
                    $data2['reply_to_message_id'] = $result->getResult()->getmessage_id();
                    $result = Request::sendMessage($data2);
                } else if ($publish_or_update === 'update') {
                    $data2['reply_to_message_id'] = $media['post_id'];
                    $data2['message_id'] = $media['post_id'] + 1;
                    $result = Request::editMessageText($data2);
                }
            }
        }
    }





    public function getVersion()
    {
        return $this->version;
    }


}
